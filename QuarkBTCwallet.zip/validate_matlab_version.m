function validate_matlab_version;

try;load validated;catch;validated='0';end

if strcmp(validated,'validated');
 % Already validated, this Matlab version in this computer
else
 % Correct example, to compare calculations of your Matlab version with it    
 pr_key='86880DEB264F6BA804E3AC6C162C03955E9C61C534A0A803F34C9E55D4977DB2';
 secret0='L1jDrd7q5EivxgAJEHmvbmurKXn1899R6KuqvRXR6qdeoT4nmJAm';
 addres0='12ADgmPucsV3dwEcUzcVXpt7hB55wHfria';

 % Obtaining address and secret, from example private key
 [px,py]=secp256k1(pr_key);
 [addres,pub_key]=BTCaddress(px,py,1);                                                          
 secret          =WIF(pr_key,1);

 % Comparing, to be sure everything is ok... 
 if strcmp(secret,secret0)*strcmp(addres,addres0)
  validated='validated';save validated validated
  disp('Your Matlab version works fine, you can start safely creating cold wallets')
 else
  clc;close;
  your_Matlab_version_is_not_safe=I_am_sorry;   
 end
end
end


%%%%%%%%%% Fuctions copied from BTCwallet, see comments there
function [addres,pub_key]=BTCaddress(px,py,compressed)
if compressed==1
    if mod(hex2dec(py(end)),2)==0;  pub_key=['02' px];
    else;                           pub_key=['03' px];
    end;else                        pub_key=['04' px py];
end
riped=ripemd160(SHA256(pub_key));
ch_sum=SHA256(SHA256(['00' riped]));
addres=['1'  hex2b58(['00' riped ch_sum(1:8)])];
end

function secret=WIF(pr_key,compressed)
Os(1:64-length(pr_key))='0';pr_key=[Os pr_key];
if compressed==1;   k=['80' pr_key '01'];  
else;               k=['80' pr_key];
end
hash2=SHA256(SHA256(k));
secret=hex2b58([k hash2(1:8)]);
end
